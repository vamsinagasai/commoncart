#Importing all Modues
try:
    import pandas as pd
except ModuleNotFoundError:
    import pip
    pip.main(['install', 'pandas'])
    import pandas as pd
try:
    import PySimpleGUI as sg
except ModuleNotFoundError:
    import pip
    pip.main(['install', 'PysimpleGUI'])
    import PySimpleGUI as sg

try:
    import tkinter as tk
except ModuleNotFoundError:
    import pip
    pip.main(['install', 'tkinter'])
    import tkinter as tk


from tkinter import ttk
from tkinter import *
#Module import Completed

#Reading excel files and assigning to products and customers list
prod_xl = pd.read_excel("./products.xlsx")
products = {}
for i in range(len(prod_xl)):
    products[prod_xl.iloc[i][0]] = {'Item': prod_xl.iloc[i][1], 'Q1': prod_xl.iloc[i]
                                    [2], 'Q2': prod_xl.iloc[i][3], 'Q3': prod_xl.iloc[i][4]}

cust_xl = pd.read_excel("./customers.xlsx")
customers = {}
for i in range(len(cust_xl)):
    customers[cust_xl.iloc[i][0]] = {
        'Name': cust_xl.iloc[i][1], 'Phone': cust_xl.iloc[i][2]}
#reading completed

#root formality
root = tk.Tk()
root.title("")
root.iconbitmap("icon.ico")

#width and height of the window
WIDTH = 600
HEIGHT = 550

# Set window in center of screen
ws = root.winfo_screenwidth()
hs = root.winfo_screenheight()
x = (ws/2) - (WIDTH/2)
y = (hs/2) - (HEIGHT/2)
root.geometry('%dx%d+%d+%d' % (WIDTH, HEIGHT, x, y))
root.resizable(False, False)

# Add image file as BAckground image
bg = tk.PhotoImage(file='fdeshome1.png')
my_Label = Label(root, image=bg)
my_Label.place(x=0,y=0, relwidth=1,relheight=1)
title = tk.Label(root, text="")
title.grid(row=0, column=0, columnspan=1, pady=10)

#User id dropdown menu for selecting user id's
user_id = tk.StringVar()
user_id.set("Select User ID")
user_id_dropdown = tk.OptionMenu(root, user_id, *list(list(customers.keys())+['Not An User']))
user_id_dropdown.grid(row=1, column=0, padx=10, pady=(10, 10))
user_id_dropdown.config(bg='#00ADB5')
user_id_dropdown.config(fg='#222831')

#Product list dropdown for selecting products
product_name = tk.StringVar(root)
product_name.set("Select Product")
item_list = []
for i in products:
    item_list.append(products[i]['Item'])
# .config is used for adding UI/UX changes for dropdowns,spinboxes,radiobuttons.
product_dropdown = tk.OptionMenu(root, product_name, *item_list)
product_dropdown.config(width=20)
product_dropdown.config(bg='#00ADB5')
product_dropdown.config(fg='#222831')

#.grid is used for placing the elements in the window at required positions. it is similar to .place but there we use x and y axis positions to place
product_dropdown.grid(row=2, column=0, padx=10, pady=10)

quality_var = tk.IntVar()
quality_var.set(1)
quality_var_1 = tk.Radiobutton(root, text="Quality 1",bg='#00ADB5',fg='#222831', variable=quality_var,relief='raised',borderwidth=1, value=1)
quality_var_1.grid(row=2, column=1, padx=10, pady=10)
quality_var_2 = tk.Radiobutton(root, text="Quality 2",bg='#00ADB5' ,fg='#222831',variable=quality_var,relief='raised',borderwidth=1, value=2)
quality_var_2.grid(row=3, column=1, padx=10, pady=10)
quality_var_3 = tk.Radiobutton(root, text="Quality 3",bg='#00ADB5',fg='#222831', variable=quality_var,relief='raised',borderwidth=1, value=3)
quality_var_3.grid(row=4, column=1, padx=10, pady=10)

quantity_var = tk.DoubleVar()
quantity_var.set(0.0)
quantity_spinbox = tk.Spinbox(root, from_=0.0, to=100.0, increment=0.50, width=5, textvariable=quantity_var)
quantity_spinbox.grid(row=2, column=4, padx=100, pady=10)
quantity_spinbox.config(bg='#00ADB5')
quantity_text = tk.Label(root, text="KG")
quantity_text.config(bg='#00ADB5')
# Place beside the spinbox
quantity_text.place(x=439, y=105)
# quantity_text.grid(row=2, column=4, padx=20)


# quantity_dropdown.config(width=5)
# quantity_dropdown.grid(row=2, column=3, padx=10, pady=10)



#remove all records
def remove_all():
    global order_tree
    global order_count

    global total_order
    global total_quantity
    global total_price

    for record in order_tree.get_children():
        order_tree.delete(record)
    # Get the list of quantity from tree
    quantity_list = []
    for i in range(len(order_tree.get_children())):
        quantity_list.append(float(order_tree.item(order_tree.get_children()[i])['values'][1]))
    total_quantity.config(text=str(sum(quantity_list)))
    # Get the list of price from tree
    price_list = []
    for i in range(len(order_tree.get_children())):
        price_list.append(float(order_tree.item(order_tree.get_children()[i])['values'][4]))
    total_price.config(text="₹" + str(sum(price_list)))
    #Get the No of Items from the List
    order_count = 1
    product_name.set("Select Product")
    quantity_var.set(0.0)
    quality_var.set(1)
    total_order.config(text=str(order_count-1))







#remove one selected item from the cart
def remove_one():
    global order_tree
    global order_count

    global total_order
    global total_quantity
    global total_price

    selected_item = order_tree.selection()[0]
    order_tree.delete(selected_item)

    # Get the list of quantity from tree
    quantity_list = []
    for i in range(len(order_tree.get_children())):
        quantity_list.append(float(order_tree.item(order_tree.get_children()[i])['values'][1]))
    total_quantity.config(text=str(sum(quantity_list)))

    # Get the list of price from tree
    price_list = []
    for i in range(len(order_tree.get_children())):
        price_list.append(float(order_tree.item(order_tree.get_children()[i])['values'][4]))
    total_price.config(text="₹" + str(sum(price_list)))

    #Get the No of Items from the List
    order_count -= 1
    product_name.set("Select Product")
    quantity_var.set(0.0)
    quality_var.set(1)

    total_order.config(text=str(order_count - 1))




# Create Submit button to submit the order and append to the tree

def submit_order(productname, quality, quantity):
    global order_tree
    global order_count

    global total_order
    global total_quantity
    global total_price    

    if quantity != 0.0:
        for i in products:
            if quality == 1:
                if products[i]['Item'] == productname:
                    price = products[i]['Q1']
            elif quality == 2:
                if products[i]['Item'] == productname:
                    price = products[i]['Q2']
            elif quality == 3:
                if products[i]['Item'] == productname:
                    price = products[i]['Q3']
        order_tree.insert("", "end", text=order_count, values=(productname, quantity, quality, price, price*quantity))
        order_count += 1
        product_name.set("Select Product")
        quantity_var.set(0.0)
        quality_var.set(1)
    
        total_order.config(text=str(order_count-1))
        # Get the list of quantity from tree
        quantity_list = []
        for i in range(len(order_tree.get_children())):
            quantity_list.append(float(order_tree.item(order_tree.get_children()[i])['values'][1]))
        total_quantity.config(text=str(sum(quantity_list)))
        # Get the list of price from tree
        price_list = []
        for i in range(len(order_tree.get_children())):
            price_list.append(float(order_tree.item(order_tree.get_children()[i])['values'][4]))
        total_price.config(text="₹"+str(sum(price_list)))

discount_applied = False

def finish_order():
    global discount_applied
    global user_id
    global total_price
    global root

    price = float(total_price.cget("text")[1:])

    if not discount_applied:
        if price > 10000:
            print(user_id.get())
            if user_id.get() not in ["Not An User", "Select User ID"]:
                discount = price * 0.12
                price = round(price - discount, 2)
                total_price.config(text="₹"+str(price))
                disc_text = "1.2%"
            else:
                discount = price * 0.01
                price = round(price - discount, 2)
                total_price.config(text="₹"+str(price))
                disc_text = "1%"

            tk.Label(root, text=f"({disc_text} Discount Applied)",bg='#00ADB5', activebackground='#EEEEEE',fg='White',relief=tk.RAISED,borderwidth=1).place(
                x=460, y=522)
            discount_applied = True



def user_registration():
    global cust_xl
    global customers

    sg.theme('TealMono')

    EXCEL_FILE = 'customers.xlsx'
    df = pd.read_excel(EXCEL_FILE)

    layout = [
        [sg.Text('Please fill the following fields for membership')],
        [sg.Text('Customer ID', size=(15, 1)), sg.InputText(key='Customer ID')],
        [sg.Text('Name', size=(15, 1)), sg.InputText(key='Name')],
        [sg.Text('Mobile number', size=(15, 1)), sg.InputText(key='Mobile number')],
        [sg.Submit(), sg.Button('Clear'), sg.Exit()]
    ]

    window = sg.Window('Customer Registration', layout)

    def clear_input():
        for key in values:
            window[key]('')
        return None

    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED or event == 'Exit':
            break
        if event == 'Clear':
            clear_input()
        if event == 'Submit':
            df = df.append(values, ignore_index=True)
            df.to_excel(EXCEL_FILE, index=False)
            sg.popup('Data saved!')
            clear_input()



submit_button = tk.Button(root, text="Add Item", bg='#00ADB5', activebackground='#EEEEEE',fg='Black',borderwidth=1, command=lambda: submit_order(product_name.get(), quality_var.get(), quantity_var.get()), relief=tk.RAISED)
# Make the submit button disabled until user selects a product  and quantity is greater than 0
submit_button.grid(row=5, column=1, columnspan=2, pady=10)

finish_button = tk.Button(root, text="Finish Order",bg='#00ADB5', activebackground='#EEEEEE',fg='Black', relief=tk.RAISED,borderwidth=1,command=finish_order )
finish_button.place(x=390, y=150)


order_tree = ttk.Treeview(root, columns=("Product", "Quantity (kg)", "Quality", "Rate", "Price"), height=7)
order_count = 1
order_tree.heading("#0", text="Order")
order_tree.heading("#1", text="Product")
order_tree.heading("#2", text="Quantity (kg)")
order_tree.heading("#3", text="Quality")
order_tree.heading("#4", text="Rate")
order_tree.heading("#5", text="Price")
order_tree.column("#0", width=50)
order_tree.column("#1", width=165)
order_tree.column("#2", width=120)
order_tree.column("#3", width=100)
order_tree.column("#4", width=80)
order_tree.column("#5", width=80)
order_tree.grid(row=6, column=0, columnspan=20, pady=10)

tk.Label(root, text="Total Items", font=("Arial", 15),bg='#00ADB5', activebackground='White',fg='White',relief='raised').place(x=21, y=470)
total_order = tk.Label(root, text="0", font=("Arial", 12))
total_order.config(width=11)
total_order.place(x=22, y=500)
total_order.config(bg='White')
total_order.config(relief='raised')
total_order.config(borderwidth=1)

tk.Label(root, text="Total Quantity (kg)", font=("Arial", 15),bg='#00ADB5', activebackground='White',fg='White',relief='raised').place(x=200, y=470)
total_quantity = tk.Label(root, text="0.0 KG", font=("Arial", 12))
total_quantity.place(x=200, y=500)
total_quantity.config(width=19)
total_quantity.config(bg='White')
total_quantity.config(relief='raised')
total_quantity.config(borderwidth=1)

tk.Label(root, text="Total Price", font=("Arial", 15),bg='#00ADB5', activebackground='White',fg='White',relief='raised',borderwidth=2).place(x=480, y=470)
total_price = tk.Label(root, text="₹0.00", font=("Arial", 12))
total_price.place(x=479, y=500)
total_price.config(width=11)
total_price.config(height=1)
total_price.config(bg='White')
total_price.config(relief='raised')
total_price.config(borderwidth=1)

#new user Registration
new_user = Button(root,text="New User Registration ", bg='#00ADB5', activebackground='#EEEEEE',fg='Black', relief=tk.RAISED,borderwidth=1,command=user_registration)
new_user.place(x=172, y=52)

##Remove all item Button
remove_all= Button(root,text="Remove all", bg='#00ADB5', activebackground='#EEEEEE',fg='Black', relief=tk.RAISED,borderwidth=1,command=remove_all)
remove_all.place(x=410, y=237)

#remove one item Button
remove_one= Button(root, text="Remove item",bg='#00ADB5', activebackground='#EEEEEE',fg='Black', relief=tk.RAISED, borderwidth=1, command=remove_one)
remove_one.place(x=300, y=237)

#def update():
#    root.update()
#update_button= Button(root, text="update button",bg='white', activebackground='#EEEEEE',fg='Black', relief=tk.RAISED, borderwidth=1, command=update)
#update_button.place(x=300, y=237)

root.mainloop()
